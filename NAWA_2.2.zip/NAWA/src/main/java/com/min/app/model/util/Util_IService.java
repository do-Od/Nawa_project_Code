package com.min.app.model.util;

public interface Util_IService {
	public String changeLC(String uc_id);
	public String getLatitude(String uc_id);
}
